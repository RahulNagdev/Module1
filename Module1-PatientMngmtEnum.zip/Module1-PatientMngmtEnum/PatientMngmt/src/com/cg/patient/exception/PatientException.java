package com.cg.patient.exception;

public class PatientException extends Exception{

	public PatientException(String msg){
		super(msg);
	}
}
