package com.cg.patient.dto;

public enum RoomType {
	Special, DoubleSharing, General;

}
